package com.clubmixbeats.dj

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.*

const val SR = 44100

class Pcm(val l: FloatArray, val r: FloatArray, val n: Int)
class Info(val bpm: Double, val phase: Int)
class Song(val uri: Uri, val name: String, val bpm: Double, val phase: Int)

class Wav(f: File) {
    private val raf = RandomAccessFile(f, "rw")
    private var bytes = 0L
    init { raf.setLength(0); raf.write(ByteArray(44)) }

    fun write(l: FloatArray, r: FloatArray, from: Int, to: Int, g: Float) {
        val chunk = 65536
        var s = from
        while (s < to) {
            val e = min(to, s + chunk)
            val buf = ByteArray((e - s) * 4)
            var o = 0
            for (i in s until e) { put(buf, o, l[i] * g); put(buf, o + 2, r[i] * g); o += 4 }
            raf.write(buf); bytes += buf.size
            s = e
        }
    }

    private fun put(b: ByteArray, o: Int, x: Float) {
        val v = (tanh((x * 1.15f).toDouble()) * 0.87 * 32767).toInt()
        b[o] = v.toByte(); b[o + 1] = (v shr 8).toByte()
    }

    fun close() {
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()).putInt((bytes + 36).toInt()).put("WAVEfmt ".toByteArray())
        h.putInt(16).putShort(1).putShort(2).putInt(SR).putInt(SR * 4).putShort(4).putShort(16)
        h.put("data".toByteArray()).putInt(bytes.toInt())
        raf.seek(0); raf.write(h.array()); raf.close()
    }
}

object Engine {
    fun decode(ctx: Context, uri: Uri): Pcm {
        val ex = MediaExtractor(); ex.setDataSource(ctx, uri, null)
        var ti = -1
        for (i in 0 until ex.trackCount)
            if (ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME)!!.startsWith("audio/")) { ti = i; break }
        require(ti >= 0) { "No audio track" }
        ex.selectTrack(ti)
        val fmt = ex.getTrackFormat(ti)
        val codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
        codec.configure(fmt, null, null, 0); codec.start()
        var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        var sr = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        val durS = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) / 1_000_000.0 else 240.0
        var l = FloatArray((durS * sr).toInt() + sr); var r = FloatArray(l.size); var n = 0
        val info = MediaCodec.BufferInfo()
        var inDone = false; var outDone = false
        while (!outDone) {
            if (!inDone) {
                val i = codec.dequeueInputBuffer(10000)
                if (i >= 0) {
                    val b = codec.getInputBuffer(i)!!
                    val s = ex.readSampleData(b, 0)
                    if (s < 0) { codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                    else { codec.queueInputBuffer(i, 0, s, ex.sampleTime, 0); ex.advance() }
                }
            }
            val o = codec.dequeueOutputBuffer(info, 10000)
            if (o >= 0) {
                val sb = codec.getOutputBuffer(o)!!.order(ByteOrder.nativeOrder()).asShortBuffer()
                val frames = sb.remaining() / ch
                if (n + frames > l.size) { l = l.copyOf(l.size * 3 / 2 + frames); r = r.copyOf(l.size) }
                for (f in 0 until frames) {
                    val a = sb.get() / 32768f
                    val b = if (ch > 1) sb.get() / 32768f else a
                    for (k in 2 until ch) sb.get()
                    l[n] = a; r[n] = b; n++
                }
                codec.releaseOutputBuffer(o, false)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
            } else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                val f = codec.outputFormat
                ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT); sr = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            }
        }
        codec.stop(); codec.release(); ex.release()
        if (sr == SR) return Pcm(l, r, n)
        val m = (n.toLong() * SR / sr).toInt()
        val a = FloatArray(m); val b = FloatArray(m); val st = sr.toDouble() / SR
        for (i in 0 until m) {
            val x = i * st; val j = x.toInt(); val f = (x - j).toFloat(); val j2 = min(j + 1, n - 1)
            a[i] = l[j] + (l[j2] - l[j]) * f; b[i] = r[j] + (r[j2] - r[j]) * f
        }
        return Pcm(a, b, m)
    }

    // Tempo (BPM) and first-beat position from the energy onsets.
    fun analyze(p: Pcm): Info {
        val hop = 256; val blk = 512; val m = (p.n - blk) / hop
        val on = FloatArray(m); var pe = 0f
        for (i in 0 until m) {
            var s = 0f; val o = i * hop; var j = 0
            while (j < blk) { val v = p.l[o + j] + p.r[o + j]; s += v * v; j += 2 }
            val e = sqrt(s); on[i] = max(0f, e - pe); pe = e
        }
        val fps = SR / hop.toDouble()
        val lo = (60 * fps / 160).toInt(); val hi = (60 * fps / 75).toInt()
        fun ac(lag: Int): Double { var s = 0.0; for (i in 0 until m - lag) s += on[i] * on[i + lag]; return s / (m - lag) }
        val sc = DoubleArray(hi + 2)
        for (lag in lo - 1..hi + 1) sc[lag] = ac(lag) + 0.5 * (if (2 * lag < m) ac(2 * lag) else 0.0)
        var bl = lo
        for (lag in lo..hi) if (sc[lag] > sc[bl]) bl = lag
        val a = sc[bl - 1]; val b = sc[bl]; val c = sc[bl + 1]
        val den = a - 2 * b + c
        val lagF = bl + if (den != 0.0) 0.5 * (a - c) / den else 0.0
        val bins = lagF.roundToInt(); val acc = FloatArray(bins)
        for (i in 0 until m) acc[min(bins - 1, (i % lagF).toInt())] += on[i]
        var pb = 0
        for (i in 1 until bins) if (acc[i] > acc[pb]) pb = i
        return Info(60 * fps / lagF, pb * hop + blk)
    }

    // Change tempo without changing pitch (WSOLA). rate > 1 = faster.
    fun stretch(p: Pcm, rate: Double): Pcm {
        if (abs(rate - 1) < 0.003) return p
        val N = 2048; val H = 512; val tol = 256; val n = p.n
        val outLen = (n / rate).toInt() + N
        val ol = FloatArray(outLen); val orr = FloatArray(outLen)
        val win = FloatArray(N) { (0.5 - 0.5 * cos(2 * PI * it / N)).toFloat() }
        var prev = 0; var k = 0
        while (true) {
            val nom = (k * H * rate).toInt()
            var pos = nom
            if (k > 0) {
                val tg = prev + H
                var best = -Float.MAX_VALUE
                var d = -tol
                while (d <= tol) {
                    val c = nom + d
                    if (c >= 0 && c + N < n && tg + N < n) {
                        var s = 0f; var i = 0
                        while (i < N / 2) { s += p.l[tg + i] * p.l[c + i]; i += 8 }
                        if (s > best) { best = s; pos = c }
                    }
                    d += 2
                }
            }
            val o = k * H
            if (pos < 0 || pos + N >= n || o + N >= outLen) break
            for (i in 0 until N) { val w = win[i] * 0.5f; ol[o + i] += p.l[pos + i] * w; orr[o + i] += p.r[pos + i] * w }
            prev = pos; k++
        }
        return Pcm(ol, orr, min(outLen, k * H + N))
    }

    private fun sm(x: Float): Float { val t = ((x - 0.45f) / 0.1f).coerceIn(0f, 1f); return t * t * (3 - 2 * t) }

    // Beat-matched club mix: all songs tempo-matched, beat-aligned, phrase-length blends, optional bass swap.
    fun mix(ctx: Context, songs: List<Song>, beats: Int, bassSwap: Boolean, out: File, say: (String) -> Unit) {
        val target = songs.map { it.bpm }.sorted()[songs.size / 2]
        val period = SR * 60.0 / target
        val ov = (beats * period).toInt()
        val w = Wav(out)
        var tl: FloatArray? = null; var tr: FloatArray? = null
        val ka = 0.028f
        for ((idx, s) in songs.withIndex()) {
            say("Mixing ${idx + 1}/${songs.size}: ${s.name}")
            var p = decode(ctx, s.uri)
            p = stretch(p, target / s.bpm)
            val st = (s.phase * s.bpm / target).toInt().coerceIn(0, p.n / 2)
            val la = p.n - st
            var e = 0.0; var c = 0; var i = 0
            while (i < la) { val v = p.l[st + i]; e += v * v; c++; i += 4 }
            val g = min(4f, 0.18f / sqrt(e / max(1, c)).toFloat())
            val last = idx == songs.lastIndex
            val ta = if (last || la < 2 * ov + period) la else max(ov, (floor((la - ov) / period) * period).toInt())
            var from = 0
            if (tl != null && tr != null) {
                val bl = FloatArray(ov); val br = FloatArray(ov)
                var lpOl = 0f; var lpOr = 0f; var lpIl = 0f; var lpIr = 0f
                for (j in 0 until ov) {
                    val x = j / ov.toFloat()
                    val gi = sin(x * PI / 2).toFloat(); val go = cos(x * PI / 2).toFloat()
                    val ol = if (j < tl.size) tl[j] else 0f; val or = if (j < tr.size) tr[j] else 0f
                    val il = p.l[st + j] * g; val ir = p.r[st + j] * g
                    if (bassSwap) {
                        lpOl += ka * (ol - lpOl); lpOr += ka * (or - lpOr); lpIl += ka * (il - lpIl); lpIr += ka * (ir - lpIr)
                        val bi = sm(x); val bo = 1 - bi
                        bl[j] = (ol - lpOl) * go + lpOl * bo + (il - lpIl) * gi + lpIl * bi
                        br[j] = (or - lpOr) * go + lpOr * bo + (ir - lpIr) * gi + lpIr * bi
                    } else { bl[j] = ol * go + il * gi; br[j] = or * go + ir * gi }
                }
                w.write(bl, br, 0, ov, 1f)
                from = ov
            }
            w.write(p.l, p.r, st + from, st + ta, g)
            if (!last) {
                tl = FloatArray(la - ta) { p.l[st + ta + it] * g }
                tr = FloatArray(la - ta) { p.r[st + ta + it] * g }
            }
        }
        w.close()
    }
}
