package com.clubmixbeats.dj

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.Gravity
import android.widget.*
import java.io.File

class MainActivity : Activity() {
    private val songs = ArrayList<Song>()
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private var beats = 16
    private var bass = true
    private var auto = true
    private var mp: MediaPlayer? = null
    private var mixFile: File? = null
    private val bg = Color.parseColor("#0E0E14")
    private val pink = Color.parseColor("#FF2E88")
    private val cyan = Color.parseColor("#27E1FF")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(t: String, c: Int, f: () -> Unit) = Button(this).apply {
        text = t; setTextColor(Color.BLACK); setBackgroundColor(c); setOnClickListener { f() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(10) }
    }

    private fun tv(t: String, sz: Float, c: Int = Color.WHITE) = TextView(this).apply { text = t; textSize = sz; setTextColor(c) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(28), dp(18), dp(28)) }
        root.addView(tv("Club Mix Beats", 30f, pink))
        root.addView(tv("Add songs. Get one beat-matched club mix.", 14f, Color.LTGRAY))
        root.addView(btn("Add songs", cyan) {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "audio/*"; addCategory(Intent.CATEGORY_OPENABLE); putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            }, 1)
        })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(8)) }
        root.addView(list)
        val bl = tv("Blend length: $beats beats", 14f)
        val sb = SeekBar(this).apply {
            max = 28; progress = beats - 4
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { beats = p + 4; bl.text = "Blend length: $beats beats" }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        root.addView(bl); root.addView(sb)
        root.addView(CheckBox(this).apply { text = "Bass swap on blends"; setTextColor(Color.WHITE); isChecked = bass; setOnCheckedChangeListener { _, v -> bass = v } })
        root.addView(CheckBox(this).apply { text = "Auto-order songs by BPM"; setTextColor(Color.WHITE); isChecked = auto; setOnCheckedChangeListener { _, v -> auto = v } })
        root.addView(btn("Create club mix", pink) { create() })
        status = tv("Add at least 2 songs.", 14f, Color.LTGRAY).apply { setPadding(0, dp(10), 0, dp(10)) }
        root.addView(status)
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        row.addView(btn("Play / Stop", cyan) { toggle() }, LinearLayout.LayoutParams(0, dp(52), 1f))
        row.addView(btn("Save to phone", cyan) { save() }, LinearLayout.LayoutParams(0, dp(52), 1f))
        root.addView(row)
        setContentView(ScrollView(this).apply { setBackgroundColor(bg); addView(root) })
    }

    private fun nameOf(u: Uri): String = try {
        contentResolver.query(u, null, null, null, null)?.use { if (it.moveToFirst()) it.getString(it.getColumnIndex(OpenableColumns.DISPLAY_NAME)) else null } ?: "Song"
    } catch (e: Exception) { "Song" }

    private fun refresh() {
        list.removeAllViews()
        songs.forEachIndexed { i, s ->
            list.addView(tv("${s.name}  -  ${"%.1f".format(s.bpm)} BPM  (tap to remove)", 14f).apply {
                setPadding(0, dp(8), 0, dp(8)); setOnClickListener { songs.removeAt(i); refresh() }
            })
        }
    }

    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        if (rc != 1 || res != RESULT_OK || d == null) return
        val uris = ArrayList<Uri>()
        d.clipData?.let { for (i in 0 until it.itemCount) uris.add(it.getItemAt(i).uri) } ?: d.data?.let { uris.add(it) }
        Thread {
            for (u in uris) {
                val n = nameOf(u)
                try {
                    runOnUiThread { status.text = "Analyzing $n ..." }
                    val p = Engine.decode(this, u)
                    val inf = Engine.analyze(p)
                    runOnUiThread { songs.add(Song(u, n, inf.bpm, inf.phase)); refresh() }
                } catch (t: Throwable) { runOnUiThread { status.text = "Could not read $n: ${t.message}" } }
            }
            runOnUiThread { status.text = "${songs.size} songs ready." }
        }.start()
    }

    private fun create() {
        if (songs.size < 2) { status.text = "Add at least 2 songs."; return }
        mp?.release(); mp = null
        val order = if (auto) songs.sortedBy { it.bpm } else songs.toList()
        val f = File(cacheDir, "mix.wav")
        Thread {
            try {
                Engine.mix(this, order, beats, bass, f) { m -> runOnUiThread { status.text = m } }
                mixFile = f
                runOnUiThread { status.text = "Mix ready. Press Play or Save."; toggle() }
            } catch (t: Throwable) { runOnUiThread { status.text = "Mix failed: ${t.message}" } }
        }.start()
    }

    private fun toggle() {
        val f = mixFile ?: return
        val m = mp
        if (m != null && m.isPlaying) { m.stop(); m.release(); mp = null; return }
        mp = MediaPlayer().apply { setDataSource(f.absolutePath); prepare(); start() }
    }

    private fun save() {
        val f = mixFile ?: run { status.text = "Create a mix first."; return }
        Thread {
            try {
                val v = ContentValues().apply {
                    put(MediaStore.Audio.Media.DISPLAY_NAME, "ClubMix_${System.currentTimeMillis() / 1000}.wav")
                    put(MediaStore.Audio.Media.MIME_TYPE, "audio/wav")
                    put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/ClubMixBeats")
                }
                val u = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, v)!!
                contentResolver.openOutputStream(u)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
                runOnUiThread { status.text = "Saved in Music/ClubMixBeats." }
            } catch (t: Throwable) { runOnUiThread { status.text = "Save failed: ${t.message}" } }
        }.start()
    }

    override fun onDestroy() { mp?.release(); super.onDestroy() }
}
